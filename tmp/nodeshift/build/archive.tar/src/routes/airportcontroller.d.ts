import * as express from 'express';
declare class ScheduleController {
  router: import('express-serve-static-core').Router;
  path: string;
  constructor();
  intializeRoutes(): void;
  getAirports: (request: express.Request, response: express.Response) => void;
  getAirport: (request: express.Request, response: express.Response) => void;
}
export default ScheduleController;
