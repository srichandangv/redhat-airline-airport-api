import express from 'express';
export declare const app: express.Application;
